<?php


//절대값 만들기
function myabs($val)
{
    return $val * (-1) ;
    
}


print myabs(-3);


?>
