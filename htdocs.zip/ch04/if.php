<?php

    if(false)
    {
        print "안녕하세요";
    }

    else
    {
        print "byebye";
    }



?>