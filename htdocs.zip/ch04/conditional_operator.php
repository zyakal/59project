<?php
    $num = 11;
    print "${num}는(은)" . ($num % 2 === 0 ? "짝" : "홀") . "수입니다.";
    print $num;

?>