<?php
    // for, while 둘 다 반복문
    // for문은 몇 번 반복해야하는지 알 때
    // while은 언제 그만둬야 하는지 알 때

     $i=0;

    while($i < 10)
    {
        print $i . "<br>";
        $i+=2;
    }


?>