<?php
    $dan = rand(2,9);
    
    for($i=1; $i<10; $i++)
    {
        $z = $dan * $i;
        print $dan . " X " . $i .  " = " . $z . "<br>";
    }
    



?> 