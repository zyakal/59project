<?php

    define("NAME", "홍길동");
    print NAME;

    // 상수 const vs 리터럴
    // define도 GLOBALS와 마찬가지로 호출만된다면 전역적으로 사용가능하다
    // 따라서 가장 위에 적는게 일반적으로 좋다
 
?>