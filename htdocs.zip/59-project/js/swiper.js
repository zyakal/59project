var swiper = new Swiper('.mySwiper', {
  slidesPerView: 3.5,
  spaceBetween: 20,
});
