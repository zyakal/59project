<?php

$_SESSION['login_store']['store_num'] = 1;

// echo $_SESSION['login_store']['store_num'];


include_once('../check_reserve_for_store.php');
?>

