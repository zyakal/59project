<?php
    include_once '../db/db_store.php';
    

    header("location: store_main.php")
?>