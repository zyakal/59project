<nav class="header--nav">
    <div class="nav--logo">
        <a href="javascript:history.back();" class="nav--back">
            <i class="fa-solid fa-arrow-left"></i>
        </a>
    </div>
    <div class="nav--addr">
        <a href="#">

            <?= $page_name ?>
        </a>
    </div>
    <div class="nav--notice">
        <a href="home.php">
            <i class="fa-solid fa-house"></i>
        </a>
    </div>
</nav>