<div class="slide__box">
    <ul class="slide__list">
        <li class="slide__item">
            <img class="slide__img" src="img/banner_icon/banner_1.jpg">
        </li>
        <li class="slide__item">
            <img class="slide__img" src="img/banner_icon/banner_2.jpg">
        </li>
        <li class="slide__item">
            <img class="slide__img" src="img/banner_icon/banner_3.jpg">
        </li>
        <li class="slide__item">
            <img class="slide__img" src="img/banner_icon/banner_4.jpg">
        </li>
        <li class="slide__item">
            <img class="slide__img" src="img/banner_icon/banner_5.jpg">
        </li>
        <li class="slide__item">
            <img class="slide__img" src="img/banner_icon/banner_6.jpg">
        </li>
    </ul>
    <div class="paginations"></div>
</div>