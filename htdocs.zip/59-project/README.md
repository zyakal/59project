# 그린버거 팀 오구 프로젝트

유용한 플러그인

-   bracket pair : 중괄호 마다 색으로 구분해주는거
-   auto close tag
-   colonize : 쉬프트 엔터 시 타이핑 중간에서 맨뒤로 세미콜론, 알트 엔터 시 중간에서 맨뒤에 세미콜론 찍고 다음줄로
-   prettier : 오토 포매팅 코드 깔끔하게 해주는것
-   px to rem : px단위 자동으로 rem 바꿔주는 것 반응형시 편함
-   Material icon theme 파일이나 폴더 테마 작업할 때 편함

CSS 사용시

-   root와 var 사용으로
-   자주쓰는거 한군데 모아놓기

font awesome kit 본인껄로 바꿔주세요

무료 이미지 불러오기 좋은 사이트

-   https://unsplash.com/

유용한 사이트 모음

-   css 애니메이션 https://animista.net/play/basic
-   그라데이션 https://cssgradient.io/
-   다양한 javascript 기능 및 꾸미기 https://codepen.io/

localhost 주소 입력 할 때 59-project 대문자로 안써도 됩니다.
