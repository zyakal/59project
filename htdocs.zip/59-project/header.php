<nav class="header--nav">
    <div class="nav--logo">
        <a href="javascript:history.back();" class="nav--back">
            <i class="fa-solid fa-arrow-left"></i>
        </a>
    </div>
    <div class="nav--addr">
        <a href="#">
            <!-- 본인페이지에서 $page_name에 페이지이름 문자열로 넣어주기  -->
            <?= $page_name ?>
        </a>
    </div>
    <div class="nav--notice">
        <a href="not.php">
        </a>
    </div>
</nav>

