<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=Neo, initial-scale=1.0">
    <title>Tabs</title>
    <link rel="stylesheet" href="tabs.css">
</head>

<body>
    <div class="tabs">
        <div class="tabs__head">
            <div class="tabs__toggle is-active">
                <span class="tabs__name">First Tab</span>
            </div>
            <div class="tabs__toggle">
                <span class="tabs__name">Second Tab</span>
            </div>
            <div class="tabs__toggle">
                <span class="tabs__name">Third Tab</span>
            </div>
        </div>
        <div class="tabs__body">
            <div class="tabs__content is-active">
                <h2 class="tabs__title">First Title</h2>
                <p class="tabs__text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, voluptates nihil reprehenderit architecto deleniti a blanditiis dolore voluptate cupiditate saepe sequi, quo iusto tempora itaque excepturi! Sunt optio nihil minus?</p>
            </div>
            <div class="tabs__content">
                <h2 class="tabs__title">Second Title</h2>
                <p class="tabs__text">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora natus voluptas, molestias voluptates consequuntur quibusdam aspernatur expedita tempore libero excepturi obcaecati earum minus omnis adipisci fuga officia, autem, perferendis voluptatibus!</p>
            </div>
            <div class="tabs__content">
                <h2 class="tabs__title">Third Title</h2>
                <p class="tabs__text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Mollitia quasi commodi nisi ex nostrum, aspernatur dicta perferendis deserunt reiciendis a delectus molestias eius porro, tempore molestiae ipsam sit quam aut officia, autem, perferendis?</p>
            </div>
        </div>
    </div>

    <script src="tabs.js"></script>
</body>

</html>