<?php
    print $g;