<?php
    setcookie("country", "Korea"); // 선언 하자마자 바로 사용은 안된다.
    ?>
    <a href="cookie2.php">Next Page</a>