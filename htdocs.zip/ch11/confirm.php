<?php
    session_start();
    echo $_SESSION['var1'], "<br>";
    echo $_SESSION['var2'], "<br>";