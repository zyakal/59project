<?php
    $age = 21;
    $blood_type = 'O';
    $name = "Alice";

    print "나이 : $age <br>";
    print "혈액형 : $blood_type <br>";
    print "이름 : $name <br>";
?>