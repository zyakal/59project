<?php
    $value = 999_999_999_999_999_997;

    print $value;
?>