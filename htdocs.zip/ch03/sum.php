<?php
    $n1 = 10;
    $n2 = 20;
    $sum = $n1 + $n2;

    print $sum;

    print "<br>";

    $sub = 12.3 - 42.72;

    print $sub;

?>