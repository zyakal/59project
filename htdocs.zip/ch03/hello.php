<?php
    print("<div>Hello PHP</div>");
    print "<div class=\"11\">Hello PHP</div>";
?>