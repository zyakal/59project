<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="post" action="chat_client.php">
        <div><label>User Name: <input type="text" name="username" size="4"></label></div>
        <input type="hidden" name="msg" value="Enter">
        <div><input type="submit" value="submit"></div>
    </form>
</body>
</html>